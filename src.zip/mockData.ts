import { Product, Category } from './types'

export const INITIAL_CATEGORIES: Category[] = [
  { id: 'all', name: 'Semua Menu' },
  { id: 'coffee', name: 'Kopi & Espresso' },
  { id: 'non-coffee', name: 'Non-Kopi & Teh' },
  { id: 'pastry', name: 'Pastry & Roti' },
  { id: 'main-course', name: 'Makanan Utama' },
  { id: 'dessert', name: 'Dessert' }
]

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'Velvet Flat White',
    category: 'coffee',
    price: 36000,
    costPrice: 16000,
    stock: 45,
    sku: 'CF-FLT-01',
    imageUrl: 'https://images.unsplash.com/photo-1577968897966-3d4325b36b61?w=500&h=500&fit=crop&auto=format',
    description: 'Espresso ganda dengan mikrobusa susu segar yang lembut dan aromatik.',
    createdAt: '2025-01-10'
  },
  {
    id: 'prod-2',
    name: 'Cold Drip Reserve Ethiopian',
    category: 'coffee',
    price: 42000,
    costPrice: 20000,
    stock: 22,
    sku: 'CF-DRP-02',
    imageUrl: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=500&h=500&fit=crop&auto=format',
    description: 'Ekstraksi dingin 12 jam dengan aroma melati, bergamot, dan rasa peach segar.',
    createdAt: '2025-01-12'
  },
  {
    id: 'prod-3',
    name: 'Artisan Iced Caramel Macchiato',
    category: 'coffee',
    price: 40000,
    costPrice: 18000,
    stock: 35,
    sku: 'CF-MAC-03',
    imageUrl: 'https://images.unsplash.com/photo-1485808191679-5f86510681a2?w=500&h=500&fit=crop&auto=format',
    description: 'Susu dingin kental dipadukan sirup vanilla organik dan drizzle saus karamel khas.',
    createdAt: '2025-01-15'
  },
  {
    id: 'prod-4',
    name: 'Kyoto Ceremonial Matcha',
    category: 'non-coffee',
    price: 38000,
    costPrice: 17000,
    stock: 28,
    sku: 'NC-MTC-01',
    imageUrl: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=500&h=500&fit=crop&auto=format',
    description: 'Bubuk matcha murni Uji Kyoto dipadu oat milk creamy dengan rasa earthy manis lembut.',
    createdAt: '2025-01-16'
  },
  {
    id: 'prod-5',
    name: 'Earl Grey Lavender Tea',
    category: 'non-coffee',
    price: 32000,
    costPrice: 11000,
    stock: 40,
    sku: 'NC-TEA-02',
    imageUrl: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=500&h=500&fit=crop&auto=format',
    description: 'Seduhan teh hitam bergamot dengan bunga lavender kering aromaterapi yang menenangkan.',
    createdAt: '2025-01-18'
  },
  {
    id: 'prod-6',
    name: 'Butter Croissant Bordier',
    category: 'pastry',
    price: 28000,
    costPrice: 13000,
    stock: 18,
    sku: 'PS-CRS-01',
    imageUrl: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=500&h=500&fit=crop&auto=format',
    description: 'Pastry berlapis renyah keemasan menggunakan 100% mentega murni Prancis.',
    createdAt: '2025-01-20'
  },
  {
    id: 'prod-7',
    name: 'Pistachio Pain au Chocolat',
    category: 'pastry',
    price: 35000,
    costPrice: 16000,
    stock: 14,
    sku: 'PS-CHO-02',
    imageUrl: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=500&h=500&fit=crop&auto=format',
    description: 'Cokelat Valrhona gelap dibalut adonan flaky dan taburan remahan kacang pistachio panggang.',
    createdAt: '2025-01-21'
  },
  {
    id: 'prod-8',
    name: 'Truffle Mushroom Risotto',
    category: 'main-course',
    price: 68000,
    costPrice: 32000,
    stock: 16,
    sku: 'MC-RST-01',
    imageUrl: 'https://images.unsplash.com/photo-1633964913295-ceb43826e7c9?w=500&h=500&fit=crop&auto=format',
    description: 'Beras arborio lembut dengan kaldu jamur liar, keju parmigiano reggiano, dan minyak truffle putih.',
    createdAt: '2025-01-22'
  },
  {
    id: 'prod-9',
    name: 'Smoked Salmon Sourdough',
    category: 'main-course',
    price: 62000,
    costPrice: 28000,
    stock: 12,
    sku: 'MC-SLM-02',
    imageUrl: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=500&h=500&fit=crop&auto=format',
    description: 'Roti sourdough panggang, cream cheese dill, salmon asap Norwegia, dan capers.',
    createdAt: '2025-01-23'
  },
  {
    id: 'prod-10',
    name: 'Basque Burnt Cheesecake',
    category: 'dessert',
    price: 38000,
    costPrice: 16000,
    stock: 15,
    sku: 'DS-CHK-01',
    imageUrl: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=500&h=500&fit=crop&auto=format',
    description: 'Cheesecake bertekstur lembut meleleh di tengah dengan permukaan karamelisasi gosong yang wangi.',
    createdAt: '2025-01-24'
  }
]
