import React, { useState, useEffect } from 'react'
import { Product, CartItem, Transaction, Category } from './types'
import { INITIAL_PRODUCTS, INITIAL_CATEGORIES } from './mockData'
import { generateInvoiceNumber } from './utils'
import { CashierView } from './components/CashierView'
import { InventoryView } from './components/InventoryView'
import { HistoryView } from './components/HistoryView'
import { ProductModal } from './components/ProductModal'
import { CategoryModal } from './components/CategoryModal'
import { ReceiptModal } from './components/ReceiptModal'
import { 
  Coffee, 
  Store, 
  Package, 
  History, 
  Sparkles, 
  UserCircle, 
  CircleDollarSign,
  Plus
} from 'lucide-react'

export default function App() {
  // Navigation active tab
  const [activeTab, setActiveTab] = useState<'cashier' | 'inventory' | 'history'>('cashier')

  // State with LocalStorage persistence
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('pos_products')
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS
  })

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('pos_categories')
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES
  })

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('pos_transactions')
    return saved ? JSON.parse(saved) : []
  })

  const [cart, setCart] = useState<CartItem[]>([])

  // Modal states
  const [isProductModalOpen, setIsProductModalOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false)
  const [currentReceipt, setCurrentReceipt] = useState<Transaction | null>(null)
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false)

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('pos_products', JSON.stringify(products))
  }, [products])

  useEffect(() => {
    localStorage.setItem('pos_categories', JSON.stringify(categories))
  }, [categories])

  useEffect(() => {
    localStorage.setItem('pos_transactions', JSON.stringify(transactions))
  }, [transactions])

  // Cart operations
  const handleAddToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id)
      if (existing) {
        if (existing.quantity >= product.stock) return prev
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      } else {
        return [...prev, { product, quantity: 1 }]
      }
    })
  }

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveFromCart(productId)
      return
    }
    setCart(prev =>
      prev.map(item =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    )
  }

  const handleRemoveFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId))
  }

  const handleClearCart = () => {
    setCart([])
  }

  // Checkout Handler
  const handleCheckout = ({
    customerName,
    paymentMethod,
    cashPaid,
    discountPercent,
    notes
  }: {
    customerName: string
    paymentMethod: 'cash' | 'qris' | 'card' | 'transfer'
    cashPaid: number
    discountPercent: number
    notes: string
  }) => {
    const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0)
    const discount = (subtotal * discountPercent) / 100
    const tax = (subtotal - discount) * 0.11
    const total = Math.max(0, subtotal - discount + tax)
    const change = Math.max(0, cashPaid - total)

    const now = new Date()
    const formattedDate = now.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })

    const newTransaction: Transaction = {
      id: `tx-${Date.now()}`,
      invoiceNumber: generateInvoiceNumber(),
      date: formattedDate,
      items: [...cart],
      subtotal,
      discount,
      tax,
      total,
      paymentMethod,
      cashPaid,
      change,
      customerName: customerName || undefined,
      cashierName: 'Arya Pradipta',
      notes: notes || undefined
    }

    // Deduct stock from products
    setProducts(prevProducts =>
      prevProducts.map(p => {
        const boughtItem = cart.find(ci => ci.product.id === p.id)
        if (boughtItem) {
          return {
            ...p,
            stock: Math.max(0, p.stock - boughtItem.quantity)
          }
        }
        return p
      })
    )

    // Save transaction
    setTransactions(prev => [newTransaction, ...prev])

    // Clear cart and show receipt modal
    setCart([])
    setCurrentReceipt(newTransaction)
    setIsReceiptModalOpen(true)
  }

  // CRUD Product Handlers
  const handleSaveProduct = (
    productData: Omit<Product, 'id' | 'createdAt'>,
    id?: string
  ) => {
    if (id) {
      // Edit
      setProducts(prev =>
        prev.map(p =>
          p.id === id
            ? { ...p, ...productData }
            : p
        )
      )
    } else {
      // Create
      const newProd: Product = {
        ...productData,
        id: `prod-${Date.now()}`,
        createdAt: new Date().toISOString().split('T')[0]
      }
      setProducts(prev => [newProd, ...prev])
    }
  }

  const handleDeleteProduct = (productId: string) => {
    setProducts(prev => prev.filter(p => p.id !== productId))
    setCart(prev => prev.filter(c => c.product.id !== productId))
  }

  // CRUD Category Handlers
  const handleAddCategory = (name: string) => {
    const id = name.toLowerCase().replace(/\s+/g, '-') + '-' + Date.now().toString().slice(-4)
    setCategories(prev => [...prev, { id, name }])
  }

  const handleDeleteCategory = (catId: string) => {
    if (catId === 'all') return
    setCategories(prev => prev.filter(c => c.id !== catId))
    // Re-assign affected products to default
    setProducts(prev =>
      prev.map(p => (p.category === catId ? { ...p, category: 'coffee' } : p))
    )
  }

  return (
    <div className="min-h-screen bg-[#fbfbf9] text-stone-900 flex flex-col font-sans selection:bg-amber-100">
      {/* Top Navbar */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-stone-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Brand Logo & Name */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-stone-900 text-amber-100 flex items-center justify-center shadow-xs">
              <Coffee className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="font-serif text-lg font-bold tracking-tight text-stone-900">
                  ATELIER POS
                </h1>
                <span className="text-[10px] font-mono uppercase tracking-widest px-1.5 py-0.5 rounded bg-amber-50 text-amber-900 border border-amber-200/60 font-semibold">
                  v2.4
                </span>
              </div>
              <p className="text-[11px] text-stone-400">Sistem Kasir & Manajemen Stok</p>
            </div>
          </div>

          {/* Navigation Pill Tabs */}
          <nav className="flex items-center p-1 bg-stone-100 rounded-xl border border-stone-200/60">
            <button
              onClick={() => setActiveTab('cashier')}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'cashier'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Store className="w-3.5 h-3.5" />
              Kasir
            </button>
            <button
              onClick={() => setActiveTab('inventory')}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'inventory'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Package className="w-3.5 h-3.5" />
              Kelola Menu (CRUD)
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'history'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              Riwayat
            </button>
          </nav>

          {/* User profile / Quick Action */}
          <div className="hidden sm:flex items-center gap-3">
            <button
              onClick={() => {
                setEditingProduct(null)
                setIsProductModalOpen(true)
              }}
              className="text-xs font-medium px-3 py-1.5 rounded-lg border border-stone-300 text-stone-700 hover:bg-stone-50 transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              Item Baru
            </button>
            <div className="flex items-center gap-2 pl-3 border-l border-stone-200">
              <div className="w-8 h-8 rounded-full bg-stone-200/80 flex items-center justify-center text-stone-700 text-xs font-bold font-serif">
                AP
              </div>
              <div className="text-left text-xs">
                <p className="font-semibold text-stone-800 leading-tight">Arya P.</p>
                <p className="text-[10px] text-stone-400">Kasir Utama</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'cashier' && (
          <CashierView
            products={products}
            categories={categories}
            cart={cart}
            onAddToCart={handleAddToCart}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveFromCart={handleRemoveFromCart}
            onClearCart={handleClearCart}
            onCheckout={handleCheckout}
          />
        )}

        {activeTab === 'inventory' && (
          <InventoryView
            products={products}
            categories={categories}
            onAddProduct={() => {
              setEditingProduct(null)
              setIsProductModalOpen(true)
            }}
            onEditProduct={prod => {
              setEditingProduct(prod)
              setIsProductModalOpen(true)
            }}
            onDeleteProduct={handleDeleteProduct}
            onManageCategories={() => setIsCategoryModalOpen(true)}
          />
        )}

        {activeTab === 'history' && (
          <HistoryView
            transactions={transactions}
            onViewReceipt={tx => {
              setCurrentReceipt(tx)
              setIsReceiptModalOpen(true)
            }}
          />
        )}
      </main>

      {/* Modals */}
      <ProductModal
        isOpen={isProductModalOpen}
        onClose={() => setIsProductModalOpen(false)}
        onSave={handleSaveProduct}
        editingProduct={editingProduct}
        categories={categories}
      />

      <CategoryModal
        isOpen={isCategoryModalOpen}
        onClose={() => setIsCategoryModalOpen(false)}
        categories={categories}
        onAddCategory={handleAddCategory}
        onDeleteCategory={handleDeleteCategory}
      />

      <ReceiptModal
        isOpen={isReceiptModalOpen}
        onClose={() => setIsReceiptModalOpen(false)}
        transaction={currentReceipt}
      />
    </div>
  )
}
