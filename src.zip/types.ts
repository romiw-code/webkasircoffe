export interface Product {
  id: string
  name: string
  category: string
  price: number
  costPrice: number
  stock: number
  sku: string
  imageUrl?: string
  description?: string
  createdAt: string
}

export interface CartItem {
  product: Product
  quantity: number
}

export interface Transaction {
  id: string
  invoiceNumber: string
  date: string
  items: CartItem[]
  subtotal: number
  discount: number
  tax: number
  total: number
  paymentMethod: 'cash' | 'qris' | 'card' | 'transfer'
  cashPaid: number
  change: number
  customerName?: string
  cashierName: string
  notes?: string
}

export interface Category {
  id: string
  name: string
  icon?: string
}
