import React, { useState, useEffect } from 'react'
import { Product, Category } from './types'
import { X, Upload, Plus, AlertCircle } from 'lucide-react'

interface ProductModalProps {
  isOpen: boolean
  onClose: () => void
  onSave: (product: Omit<Product, 'id' | 'createdAt'>, id?: string) => void
  editingProduct?: Product | null
  categories: Category[]
}

export const ProductModal: React.FC<ProductModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingProduct,
  categories
}) => {
  const [name, setName] = useState('')
  const [category, setCategory] = useState('')
  const [price, setPrice] = useState<number | ''>('')
  const [costPrice, setCostPrice] = useState<number | ''>('')
  const [stock, setStock] = useState<number | ''>('')
  const [sku, setSku] = useState('')
  const [imageUrl, setImageUrl] = useState('')
  const [description, setDescription] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})

  const availableCategories = categories.filter(c => c.id !== 'all')

  useEffect(() => {
    if (editingProduct) {
      setName(editingProduct.name)
      setCategory(editingProduct.category)
      setPrice(editingProduct.price)
      setCostPrice(editingProduct.costPrice)
      setStock(editingProduct.stock)
      setSku(editingProduct.sku)
      setImageUrl(editingProduct.imageUrl || '')
      setDescription(editingProduct.description || '')
    } else {
      setName('')
      setCategory(availableCategories[0]?.id || '')
      setPrice('')
      setCostPrice('')
      setStock(10)
      setSku(`SKU-${Math.floor(1000 + Math.random() * 9000)}`)
      setImageUrl('')
      setDescription('')
    }
    setErrors({})
  }, [editingProduct, isOpen])

  if (!isOpen) return null

  const validate = () => {
    const errs: Record<string, string> = {}
    if (!name.trim()) errs.name = 'Nama produk wajib diisi'
    if (!category) errs.category = 'Pilih kategori produk'
    if (price === '' || Number(price) <= 0) errs.price = 'Harga jual harus lebih dari 0'
    if (costPrice === '' || Number(costPrice) < 0) errs.costPrice = 'Harga modal tidak boleh negatif'
    if (stock === '' || Number(stock) < 0) errs.stock = 'Stok tidak boleh negatif'
    if (!sku.trim()) errs.sku = 'SKU / Kode barang wajib diisi'
    setErrors(errs)
    return Object.keys(errs).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!validate()) return

    onSave(
      {
        name: name.trim(),
        category,
        price: Number(price),
        costPrice: Number(costPrice),
        stock: Number(stock),
        sku: sku.trim(),
        imageUrl: imageUrl.trim() || undefined,
        description: description.trim() || undefined
      },
      editingProduct ? editingProduct.id : undefined
    )
    onClose()
  }

  // Preset quick images
  const sampleImages = [
    { label: 'Kopi Espresso', url: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=500&h=500&fit=crop&auto=format' },
    { label: 'Iced Latte', url: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=500&h=500&fit=crop&auto=format' },
    { label: 'Croissant', url: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=500&h=500&fit=crop&auto=format' },
    { label: 'Cake', url: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=500&h=500&fit=crop&auto=format' },
    { label: 'Sandwich', url: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=500&h=500&fit=crop&auto=format' }
  ]

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full max-h-[90vh] flex flex-col border border-stone-200 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between bg-stone-50/50">
          <div>
            <h3 className="font-serif text-xl font-semibold text-stone-900">
              {editingProduct ? 'Edit Menu / Produk' : 'Tambah Menu Baru'}
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              {editingProduct ? 'Perbarui informasi dan harga produk di katalog' : 'Tambahkan item baru ke dalam katalog kasir'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                Nama Produk *
              </label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Contoh: Signature Cold Brew"
                className={`w-full px-3.5 py-2.5 rounded-lg border text-sm text-stone-900 bg-stone-50/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-900/20 focus:border-amber-900 transition-all ${
                  errors.name ? 'border-red-400 ring-1 ring-red-400' : 'border-stone-300'
                }`}
              />
              {errors.name && <p className="text-xs text-red-500 mt-1 flex items-center gap-1"><AlertCircle className="w-3.5 h-3.5" />{errors.name}</p>}
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                Kategori *
              </label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-sm text-stone-900 bg-stone-50/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-900/20 focus:border-amber-900 transition-all"
              >
                {availableCategories.map(cat => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                SKU / Kode Barang *
              </label>
              <input
                type="text"
                value={sku}
                onChange={e => setSku(e.target.value)}
                placeholder="SKU-001"
                className={`w-full px-3.5 py-2.5 rounded-lg border text-sm font-mono text-stone-900 bg-stone-50/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-900/20 focus:border-amber-900 transition-all ${
                  errors.sku ? 'border-red-400 ring-1 ring-red-400' : 'border-stone-300'
                }`}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                Harga Jual (Rp) *
              </label>
              <input
                type="number"
                value={price}
                onChange={e => setPrice(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="35000"
                className={`w-full px-3.5 py-2.5 rounded-lg border text-sm text-stone-900 bg-stone-50/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-900/20 focus:border-amber-900 transition-all ${
                  errors.price ? 'border-red-400 ring-1 ring-red-400' : 'border-stone-300'
                }`}
              />
              {errors.price && <p className="text-xs text-red-500 mt-1">{errors.price}</p>}
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                Harga Modal (Rp)
              </label>
              <input
                type="number"
                value={costPrice}
                onChange={e => setCostPrice(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="15000"
                className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-sm text-stone-900 bg-stone-50/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-900/20 focus:border-amber-900 transition-all"
              />
            </div>

            <div className="col-span-2 sm:col-span-1">
              <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                Stok Awal / Tersedia *
              </label>
              <input
                type="number"
                value={stock}
                onChange={e => setStock(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="25"
                className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-sm text-stone-900 bg-stone-50/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-900/20 focus:border-amber-900 transition-all"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                URL Gambar Foto
              </label>
              <input
                type="url"
                value={imageUrl}
                onChange={e => setImageUrl(e.target.value)}
                placeholder="https://images.unsplash.com/photo-..."
                className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-sm text-stone-900 bg-stone-50/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-900/20 focus:border-amber-900 transition-all"
              />
              <div className="mt-2 flex items-center gap-1.5 flex-wrap">
                <span className="text-[11px] text-stone-400">Pilih cepat:</span>
                {sampleImages.map(img => (
                  <button
                    key={img.label}
                    type="button"
                    onClick={() => setImageUrl(img.url)}
                    className="text-[11px] px-2 py-0.5 rounded bg-stone-100 hover:bg-stone-200 text-stone-700 border border-stone-200 transition-colors"
                  >
                    {img.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="col-span-2">
              <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                Deskripsi Singkat
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Rasa kaya dengan sentuhan aromatik rempah..."
                className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-sm text-stone-900 bg-stone-50/30 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-900/20 focus:border-amber-900 transition-all"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-stone-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-sm font-medium text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-sm transition-all"
            >
              {editingProduct ? 'Simpan Perubahan' : 'Tambahkan Produk'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
