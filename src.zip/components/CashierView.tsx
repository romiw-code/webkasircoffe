import React, { useState } from 'react'
import { Product, CartItem, Category } from '../types'
import { formatRupiah } from '../utils'
import { 
  Search, 
  Plus, 
  Minus, 
  Trash2, 
  ShoppingBag, 
  CreditCard, 
  QrCode, 
  Banknote, 
  ArrowRight,
  User,
  Percent,
  Check,
  AlertCircle
} from 'lucide-react'

interface CashierViewProps {
  products: Product[]
  categories: Category[]
  cart: CartItem[]
  onAddToCart: (product: Product) => void
  onUpdateQuantity: (productId: string, quantity: number) => void
  onRemoveFromCart: (productId: string) => void
  onClearCart: () => void
  onCheckout: (checkoutData: {
    customerName: string
    paymentMethod: 'cash' | 'qris' | 'card' | 'transfer'
    cashPaid: number
    discountPercent: number
    notes: string
  }) => void
}

export const CashierView: React.FC<CashierViewProps> = ({
  products,
  categories,
  cart,
  onAddToCart,
  onUpdateQuantity,
  onRemoveFromCart,
  onClearCart,
  onCheckout
}) => {
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [customerName, setCustomerName] = useState('')
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'qris' | 'card' | 'transfer'>('cash')
  const [cashPaidInput, setCashPaidInput] = useState<string>('')
  const [discountPercent, setDiscountPercent] = useState<number>(0)
  const [notes, setNotes] = useState('')
  const [checkoutError, setCheckoutError] = useState<string | null>(null)

  // Filtering products
  const filteredProducts = products.filter(p => {
    const matchesCat = selectedCategory === 'all' || p.category === selectedCategory
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCat && matchesSearch
  })

  // Cart calculations
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0)
  const discountAmount = (subtotal * discountPercent) / 100
  const taxAmount = (subtotal - discountAmount) * 0.11 // PPN 11%
  const grandTotal = Math.max(0, subtotal - discountAmount + taxAmount)

  const cashPaidNum = cashPaidInput === '' ? 0 : Number(cashPaidInput)
  const change = Math.max(0, cashPaidNum - grandTotal)

  const handleProcessPayment = () => {
    if (cart.length === 0) {
      setCheckoutError('Keranjang belanja masih kosong!')
      return
    }

    if (paymentMethod === 'cash') {
      if (cashPaidNum < grandTotal) {
        setCheckoutError(`Nominal uang tunai kurang dari total (${formatRupiah(grandTotal)})`)
        return
      }
    }

    setCheckoutError(null)
    onCheckout({
      customerName: customerName.trim(),
      paymentMethod,
      cashPaid: paymentMethod === 'cash' ? cashPaidNum : grandTotal,
      discountPercent,
      notes
    })

    // Reset checkout fields
    setCustomerName('')
    setCashPaidInput('')
    setDiscountPercent(0)
    setNotes('')
  }

  // Quick cash buttons
  const quickCashOptions = [
    grandTotal,
    Math.ceil(grandTotal / 50000) * 50000 || 50000,
    Math.ceil(grandTotal / 100000) * 100000 || 100000
  ].filter((v, idx, arr) => v > 0 && arr.indexOf(v) === idx)

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Left Menu Selection (7 cols) */}
      <div className="lg:col-span-7 xl:col-span-8 space-y-5">
        {/* Search & Category Pills */}
        <div className="space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Cari menu kopi, makanan, minuman, pastry..."
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-stone-200 bg-white text-sm text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-900/15 focus:border-amber-900 transition-all shadow-xs"
            />
          </div>

          {/* Categories Tab */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {categories.map(cat => {
              const isActive = selectedCategory === cat.id
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-stone-900 text-white shadow-xs'
                      : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200/80'
                  }`}
                >
                  {cat.name}
                </button>
              )
            })}
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredProducts.map(product => {
            const inCart = cart.find(c => c.product.id === product.id)
            const isOutOfStock = product.stock <= 0

            return (
              <div
                key={product.id}
                onClick={() => !isOutOfStock && onAddToCart(product)}
                className={`group relative bg-white rounded-xl border p-3 flex flex-col justify-between transition-all duration-200 ${
                  isOutOfStock
                    ? 'opacity-60 cursor-not-allowed border-stone-200'
                    : 'cursor-pointer hover:border-stone-400 hover:shadow-md active:scale-[0.98] border-stone-200/90'
                }`}
              >
                {/* Image */}
                <div className="w-full aspect-square rounded-lg bg-stone-100 overflow-hidden relative mb-2.5">
                  {product.imageUrl ? (
                    <img
                      src={product.imageUrl}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-stone-400 font-serif text-2xl font-bold bg-stone-50">
                      {product.name[0]}
                    </div>
                  )}

                  {inCart && (
                    <div className="absolute top-2 right-2 bg-stone-900 text-white text-[11px] font-bold px-2 py-0.5 rounded-full shadow-md">
                      {inCart.quantity}
                    </div>
                  )}

                  {isOutOfStock && (
                    <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-[1px] flex items-center justify-center">
                      <span className="text-white text-xs font-semibold px-2 py-1 rounded bg-stone-900/80">
                        Habis
                      </span>
                    </div>
                  )}
                </div>

                {/* Details */}
                <div>
                  <div className="flex items-start justify-between gap-1 mb-1">
                    <h4 className="font-medium text-stone-900 text-sm line-clamp-1 leading-snug">
                      {product.name}
                    </h4>
                  </div>
                  <p className="text-[11px] text-stone-400 font-mono mb-2">
                    Stok: {product.stock}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-stone-100">
                  <span className="font-serif font-semibold text-stone-900 text-sm">
                    {formatRupiah(product.price)}
                  </span>
                  <div className="w-6 h-6 rounded-md bg-stone-100 group-hover:bg-stone-900 group-hover:text-white flex items-center justify-center text-stone-600 transition-colors">
                    <Plus className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-16 bg-white rounded-xl border border-stone-200/80">
            <ShoppingBag className="w-10 h-10 mx-auto text-stone-300 mb-2" />
            <p className="text-sm font-medium text-stone-600">Tidak ada produk ditemukan</p>
            <p className="text-xs text-stone-400">Coba ubah kata kunci atau pilih kategori lain</p>
          </div>
        )}
      </div>

      {/* Right Checkout Panel / Cart (5 cols) */}
      <div className="lg:col-span-5 xl:col-span-4 bg-white rounded-2xl border border-stone-200/90 shadow-sm p-5 space-y-5 sticky top-24">
        {/* Cart Header */}
        <div className="flex items-center justify-between pb-3 border-b border-stone-100">
          <div>
            <h3 className="font-serif text-lg font-bold text-stone-900">Pesanan Aktif</h3>
            <p className="text-xs text-stone-400">{cart.length} jenis item di keranjang</p>
          </div>
          {cart.length > 0 && (
            <button
              onClick={onClearCart}
              className="text-xs text-red-600 hover:text-red-700 font-medium hover:underline flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" /> Kosongkan
            </button>
          )}
        </div>

        {/* Customer Input */}
        <div className="space-y-1">
          <label className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider block">
            Nama Pelanggan (Opsional)
          </label>
          <div className="relative">
            <User className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={customerName}
              onChange={e => setCustomerName(e.target.value)}
              placeholder="Contoh: Meja 04 - Bpk. Arya"
              className="w-full pl-8 pr-3 py-2 text-xs rounded-lg border border-stone-200 bg-stone-50/50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-stone-800"
            />
          </div>
        </div>

        {/* Cart Items List */}
        <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
          {cart.length === 0 ? (
            <div className="py-8 text-center text-stone-400 space-y-1">
              <ShoppingBag className="w-8 h-8 mx-auto text-stone-300 stroke-[1.5]" />
              <p className="text-xs text-stone-500 font-medium">Keranjang masih kosong</p>
              <p className="text-[11px] text-stone-400">Ketuk item di sebelah kiri untuk menambahkan</p>
            </div>
          ) : (
            cart.map(item => (
              <div
                key={item.product.id}
                className="flex items-center justify-between p-2.5 rounded-lg border border-stone-100 bg-stone-50/50 hover:bg-stone-50"
              >
                <div className="flex-1 pr-2">
                  <h5 className="text-xs font-semibold text-stone-900 leading-tight">
                    {item.product.name}
                  </h5>
                  <p className="text-[11px] text-stone-500 font-medium">
                    {formatRupiah(item.product.price)}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center border border-stone-200 rounded-md bg-white">
                    <button
                      onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                      className="p-1 hover:bg-stone-100 text-stone-600 rounded-l"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-7 text-center text-xs font-semibold text-stone-800 font-mono">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                      disabled={item.quantity >= item.product.stock}
                      className="p-1 hover:bg-stone-100 text-stone-600 rounded-r disabled:opacity-30"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <button
                    onClick={() => onRemoveFromCart(item.product.id)}
                    className="p-1 text-stone-400 hover:text-red-600"
                    title="Hapus"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Discount & Payment method toggles */}
        <div className="space-y-3 pt-2 border-t border-stone-100">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs text-stone-600 font-medium flex items-center gap-1">
              <Percent className="w-3.5 h-3.5 text-stone-400" /> Diskon
            </span>
            <div className="flex gap-1">
              {[0, 5, 10, 15].map(pct => (
                <button
                  key={pct}
                  onClick={() => setDiscountPercent(pct)}
                  className={`text-[11px] px-2 py-1 rounded border transition-colors ${
                    discountPercent === pct
                      ? 'bg-stone-900 text-white border-stone-900'
                      : 'border-stone-200 text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  {pct}%
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider block mb-1.5">
              Metode Pembayaran
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {[
                { id: 'cash', label: 'Tunai', icon: Banknote },
                { id: 'qris', label: 'QRIS', icon: QrCode },
                { id: 'card', label: 'Kartu', icon: CreditCard },
                { id: 'transfer', label: 'Transfer', icon: ArrowRight }
              ].map(method => {
                const Icon = method.icon
                const isSelected = paymentMethod === method.id
                return (
                  <button
                    key={method.id}
                    onClick={() => setPaymentMethod(method.id as any)}
                    className={`py-2 px-1 text-center rounded-lg border text-xs font-medium flex flex-col items-center gap-1 transition-all ${
                      isSelected
                        ? 'border-stone-900 bg-stone-900 text-white shadow-xs'
                        : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span className="text-[10px]">{method.label}</span>
                  </button>
                )
              })}
            </div>
          </div>

          {/* If Cash, show cash received input */}
          {paymentMethod === 'cash' && cart.length > 0 && (
            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-medium text-stone-700">Uang Diterima:</span>
                <input
                  type="number"
                  value={cashPaidInput}
                  onChange={e => setCashPaidInput(e.target.value)}
                  placeholder={grandTotal.toString()}
                  className="w-32 px-2 py-1 text-right text-xs rounded border border-stone-300 font-mono focus:outline-none focus:ring-1 focus:ring-stone-800"
                />
              </div>

              {/* Quick cash suggestions */}
              <div className="flex gap-1.5 justify-end flex-wrap">
                {quickCashOptions.map(val => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setCashPaidInput(val.toString())}
                    className="text-[10px] px-2 py-0.5 bg-white border border-stone-200 hover:border-stone-400 rounded text-stone-700 font-mono transition-colors"
                  >
                    {formatRupiah(val)}
                  </button>
                ))}
              </div>

              {cashPaidNum > 0 && (
                <div className="flex justify-between items-center text-xs pt-1 border-t border-stone-200/60 font-medium">
                  <span className="text-stone-600">Kembalian:</span>
                  <span className={change >= 0 ? 'text-emerald-700 font-bold' : 'text-red-600'}>
                    {change >= 0 ? formatRupiah(change) : 'Kurang ' + formatRupiah(Math.abs(cashPaidNum - grandTotal))}
                  </span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Pricing Summary */}
        <div className="space-y-1.5 pt-3 border-t border-stone-100 text-xs">
          <div className="flex justify-between text-stone-500">
            <span>Subtotal</span>
            <span className="font-mono">{formatRupiah(subtotal)}</span>
          </div>
          {discountAmount > 0 && (
            <div className="flex justify-between text-emerald-700">
              <span>Diskon ({discountPercent}%)</span>
              <span className="font-mono">-{formatRupiah(discountAmount)}</span>
            </div>
          )}
          <div className="flex justify-between text-stone-500">
            <span>PPN (11%)</span>
            <span className="font-mono">{formatRupiah(taxAmount)}</span>
          </div>
          <div className="flex justify-between font-serif font-bold text-base text-stone-900 pt-2 border-t border-stone-200">
            <span>Total Tagihan</span>
            <span className="text-lg">{formatRupiah(grandTotal)}</span>
          </div>
        </div>

        {checkoutError && (
          <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-xs text-red-600 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{checkoutError}</span>
          </div>
        )}

        {/* Checkout Button */}
        <button
          onClick={handleProcessPayment}
          disabled={cart.length === 0}
          className="w-full py-3 px-4 bg-stone-900 hover:bg-stone-800 disabled:opacity-40 disabled:hover:bg-stone-900 text-white rounded-xl font-medium text-sm transition-all shadow-md active:scale-[0.99] flex items-center justify-center gap-2"
        >
          <Check className="w-4 h-4" />
          Proses Pembayaran & Cetak
        </button>
      </div>
    </div>
  )
}
