import React, { useState } from 'react'
import { Category } from '../types'
import { X, Tag, Plus, Trash2 } from 'lucide-react'

interface CategoryModalProps {
  isOpen: boolean
  onClose: () => void
  categories: Category[]
  onAddCategory: (name: string) => void
  onDeleteCategory: (id: string) => void
}

export const CategoryModal: React.FC<CategoryModalProps> = ({
  isOpen,
  onClose,
  categories,
  onAddCategory,
  onDeleteCategory
}) => {
  const [newCatName, setNewCatName] = useState('')

  if (!isOpen) return null

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newCatName.trim()) return
    onAddCategory(newCatName.trim())
    setNewCatName('')
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-stone-200 overflow-hidden flex flex-col">
        <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between bg-stone-50/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-50 text-amber-900 rounded-lg border border-amber-200/50">
              <Tag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif text-lg font-semibold text-stone-900">Kelola Kategori</h3>
              <p className="text-xs text-stone-500">Kelola grup kategori produk kasir</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-stone-400 hover:text-stone-700 rounded-full hover:bg-stone-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          <form onSubmit={handleAdd} className="flex gap-2">
            <input
              type="text"
              value={newCatName}
              onChange={e => setNewCatName(e.target.value)}
              placeholder="Nama kategori baru..."
              className="flex-1 px-3.5 py-2 text-sm rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-900/20 focus:border-amber-900"
            />
            <button
              type="submit"
              disabled={!newCatName.trim()}
              className="px-4 py-2 bg-stone-900 text-white rounded-lg text-sm font-medium hover:bg-stone-800 disabled:opacity-50 transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" /> Tambah
            </button>
          </form>

          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            <p className="text-xs font-semibold uppercase tracking-wider text-stone-400">Daftar Kategori Aktif</p>
            {categories.map(cat => (
              <div
                key={cat.id}
                className="flex items-center justify-between px-3.5 py-2.5 rounded-lg border border-stone-100 bg-stone-50/60 hover:bg-stone-100/70 transition-colors"
              >
                <span className="text-sm font-medium text-stone-800">{cat.name}</span>
                {cat.id !== 'all' ? (
                  <button
                    onClick={() => onDeleteCategory(cat.id)}
                    className="p-1.5 text-stone-400 hover:text-red-600 rounded hover:bg-red-50 transition-colors"
                    title="Hapus kategori"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                ) : (
                  <span className="text-[11px] text-stone-400 uppercase tracking-wider px-2 py-0.5 bg-stone-200/60 rounded">
                    Default
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="px-6 py-3.5 bg-stone-50 border-t border-stone-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-stone-700 hover:text-stone-900 hover:bg-stone-200/60 rounded-lg transition-colors"
          >
            Selesai
          </button>
        </div>
      </div>
    </div>
  )
}
