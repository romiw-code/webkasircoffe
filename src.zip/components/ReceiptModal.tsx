import React from 'react'
import { Transaction } from '../types'
import { formatRupiah } from '../utils'
import { X, Printer, CheckCircle2, Coffee } from 'lucide-react'

interface ReceiptModalProps {
  transaction: Transaction | null
  isOpen: boolean
  onClose: () => void
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  transaction,
  isOpen,
  onClose
}) => {
  if (!isOpen || !transaction) return null

  const handlePrint = () => {
    window.print()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full border border-stone-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Top Bar */}
        <div className="px-5 py-3.5 border-b border-stone-100 flex items-center justify-between bg-stone-50/70">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <span className="text-sm font-semibold text-stone-800">Transaksi Berhasil</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-200/50 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Struk Area */}
        <div className="overflow-y-auto p-6 bg-stone-50/30 flex justify-center">
          <div
            id="printable-receipt"
            className="w-full bg-white p-6 rounded-xl border border-stone-200 shadow-xs font-mono text-xs text-stone-800 leading-relaxed"
          >
            {/* Header Struk */}
            <div className="text-center pb-4 mb-4 border-b border-dashed border-stone-300">
              <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-stone-900 text-amber-200 mb-2">
                <Coffee className="w-4 h-4" />
              </div>
              <h2 className="font-serif text-lg font-bold text-stone-900 tracking-wide">ATELIER CAFÉ & CO.</h2>
              <p className="text-[11px] text-stone-500 font-sans">Jl. Senopati No. 42, Kebayoran Baru</p>
              <p className="text-[11px] text-stone-500 font-sans">Jakarta Selatan • 021-5550199</p>
            </div>

            {/* Info Transaksi */}
            <div className="space-y-1 mb-4 text-[11px] text-stone-600 pb-3 border-b border-dashed border-stone-200">
              <div className="flex justify-between">
                <span>No. Bukti</span>
                <span className="font-semibold text-stone-800">{transaction.invoiceNumber}</span>
              </div>
              <div className="flex justify-between">
                <span>Waktu</span>
                <span>{transaction.date}</span>
              </div>
              <div className="flex justify-between">
                <span>Kasir</span>
                <span>{transaction.cashierName}</span>
              </div>
              {transaction.customerName && (
                <div className="flex justify-between">
                  <span>Pelanggan</span>
                  <span className="font-medium">{transaction.customerName}</span>
                </div>
              )}
            </div>

            {/* Item list */}
            <div className="space-y-2 mb-4 pb-3 border-b border-dashed border-stone-200">
              {transaction.items.map((item, idx) => (
                <div key={idx} className="flex justify-between text-xs items-start">
                  <div className="pr-2 flex-1">
                    <div className="text-stone-900 font-medium">{item.product.name}</div>
                    <div className="text-[10px] text-stone-500">
                      {item.quantity} × {formatRupiah(item.product.price)}
                    </div>
                  </div>
                  <div className="font-medium text-stone-900 text-right">
                    {formatRupiah(item.quantity * item.product.price)}
                  </div>
                </div>
              ))}
            </div>

            {/* Total calculation */}
            <div className="space-y-1 text-xs mb-4 pb-3 border-b border-dashed border-stone-300">
              <div className="flex justify-between text-stone-600">
                <span>Subtotal</span>
                <span>{formatRupiah(transaction.subtotal)}</span>
              </div>
              {transaction.discount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>Diskon</span>
                  <span>-{formatRupiah(transaction.discount)}</span>
                </div>
              )}
              {transaction.tax > 0 && (
                <div className="flex justify-between text-stone-600">
                  <span>PPN (11%)</span>
                  <span>{formatRupiah(transaction.tax)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-sm text-stone-900 pt-2 border-t border-stone-200">
                <span>TOTAL</span>
                <span>{formatRupiah(transaction.total)}</span>
              </div>
            </div>

            {/* Pembayaran & Kembalian */}
            <div className="space-y-1 text-[11px] text-stone-600 mb-6">
              <div className="flex justify-between">
                <span>Metode Bayar</span>
                <span className="uppercase font-semibold text-stone-800">{transaction.paymentMethod}</span>
              </div>
              <div className="flex justify-between">
                <span>Bayar Tunai</span>
                <span>{formatRupiah(transaction.cashPaid)}</span>
              </div>
              <div className="flex justify-between font-medium text-stone-900">
                <span>Kembalian</span>
                <span>{formatRupiah(transaction.change)}</span>
              </div>
            </div>

            {/* Footer Ucapan */}
            <div className="text-center text-[10px] text-stone-500 space-y-1 pt-2">
              <p>Terima kasih atas kunjungan Anda.</p>
              <p className="italic">Kelezatan rasa dalam setiap racikan.</p>
              <p className="text-[9px] text-stone-400 mt-2">www.ateliercafe.co.id</p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-4 bg-white border-t border-stone-100 flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
          >
            Tutup
          </button>
          <button
            onClick={handlePrint}
            className="flex-1 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-stone-900 hover:bg-stone-800 rounded-lg shadow-sm transition-all flex items-center justify-center gap-2"
          >
            <Printer className="w-3.5 h-3.5" /> Cetak Struk
          </button>
        </div>
      </div>
    </div>
  )
}
