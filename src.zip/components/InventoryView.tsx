import React, { useState } from 'react'
import { Product, Category } from '../types'
import { formatRupiah } from '../utils'
import { 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  Package, 
  AlertTriangle, 
  SlidersHorizontal,
  Tags
} from 'lucide-react'

interface InventoryViewProps {
  products: Product[]
  categories: Category[]
  onAddProduct: () => void
  onEditProduct: (product: Product) => void
  onDeleteProduct: (productId: string) => void
  onManageCategories: () => void
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  products,
  categories,
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  onManageCategories
}) => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')

  const filteredProducts = products.filter(p => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const lowStockCount = products.filter(p => p.stock <= 15).length
  const totalValue = products.reduce((acc, p) => acc + p.price * p.stock, 0)

  return (
    <div className="space-y-6">
      {/* Top metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-xl bg-white border border-stone-200/80 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1">Total Produk</p>
            <p className="font-serif text-2xl font-bold text-stone-900">{products.length} Menu</p>
          </div>
          <div className="p-3 bg-stone-100 rounded-lg text-stone-700">
            <Package className="w-5 h-5" />
          </div>
        </div>

        <div className="p-5 rounded-xl bg-white border border-stone-200/80 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1">Stok Menipis (≤15)</p>
            <p className="font-serif text-2xl font-bold text-amber-700">{lowStockCount} Item</p>
          </div>
          <div className="p-3 bg-amber-50 rounded-lg text-amber-700">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>

        <div className="p-5 rounded-xl bg-white border border-stone-200/80 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1">Estimasi Nilai Stok</p>
            <p className="font-serif text-2xl font-bold text-stone-900">{formatRupiah(totalValue)}</p>
          </div>
          <div className="p-3 bg-stone-100 rounded-lg text-stone-700">
            <SlidersHorizontal className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Action and Filter Toolbar */}
      <div className="bg-white rounded-xl border border-stone-200/80 shadow-xs p-4 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="flex flex-1 gap-2.5">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Cari berdasarkan nama produk atau SKU..."
              className="w-full pl-9 pr-3.5 py-2 text-sm rounded-lg border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-900/20 focus:border-amber-900 bg-stone-50/50"
            />
          </div>

          <select
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            className="px-3 py-2 text-sm rounded-lg border border-stone-200 bg-stone-50/50 text-stone-800 focus:outline-none focus:ring-2 focus:ring-amber-900/20"
          >
            {categories.map(c => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onManageCategories}
            className="px-3.5 py-2 border border-stone-300 text-stone-700 rounded-lg text-sm font-medium hover:bg-stone-50 transition-colors flex items-center gap-1.5"
          >
            <Tags className="w-4 h-4 text-stone-500" />
            Kategori
          </button>
          <button
            onClick={onAddProduct}
            className="px-4 py-2 bg-stone-900 text-white rounded-lg text-sm font-medium hover:bg-stone-800 transition-colors shadow-sm flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            Tambah Produk
          </button>
        </div>
      </div>

      {/* CRUD Product Table */}
      <div className="bg-white rounded-xl border border-stone-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-stone-50/70 border-b border-stone-100 text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
              <tr>
                <th className="px-6 py-3.5">Produk</th>
                <th className="px-6 py-3.5">Kategori</th>
                <th className="px-6 py-3.5">SKU</th>
                <th className="px-6 py-3.5 text-right">Modal</th>
                <th className="px-6 py-3.5 text-right">Harga Jual</th>
                <th className="px-6 py-3.5 text-center">Stok</th>
                <th className="px-6 py-3.5 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredProducts.map(product => {
                const isLowStock = product.stock <= 15
                const catObj = categories.find(c => c.id === product.category)
                return (
                  <tr key={product.id} className="hover:bg-stone-50/50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-stone-100 border border-stone-200 overflow-hidden shrink-0">
                          {product.imageUrl ? (
                            <img
                              src={product.imageUrl}
                              alt={product.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-stone-400 font-serif font-bold">
                              {product.name[0]}
                            </div>
                          )}
                        </div>
                        <div>
                          <p className="font-medium text-stone-900">{product.name}</p>
                          <p className="text-xs text-stone-400 line-clamp-1 max-w-[240px]">
                            {product.description || 'Tanpa deskripsi'}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-xs px-2.5 py-1 rounded-full bg-stone-100 text-stone-700 font-medium">
                        {catObj?.name || product.category}
                      </span>
                    </td>
                    <td className="px-6 py-4 font-mono text-xs text-stone-600">{product.sku}</td>
                    <td className="px-6 py-4 text-right text-xs text-stone-500">
                      {formatRupiah(product.costPrice)}
                    </td>
                    <td className="px-6 py-4 text-right font-semibold text-stone-900">
                      {formatRupiah(product.price)}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                          isLowStock
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-50 text-emerald-700'
                        }`}
                      >
                        {isLowStock && <AlertTriangle className="w-3 h-3" />}
                        {product.stock}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onEditProduct(product)}
                          className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
                          title="Edit produk"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`Yakin ingin menghapus ${product.name}?`)) {
                              onDeleteProduct(product.id)
                            }
                          }}
                          className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Hapus produk"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
