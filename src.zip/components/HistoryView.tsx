import React from 'react'
import { Transaction } from '../types'
import { formatRupiah } from '../utils'
import { Receipt, Calendar, User, CreditCard, ChevronRight, Eye } from 'lucide-react'

interface HistoryViewProps {
  transactions: Transaction[]
  onViewReceipt: (transaction: Transaction) => void
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  transactions,
  onViewReceipt
}) => {
  const totalRevenue = transactions.reduce((sum, t) => sum + t.total, 0)
  const totalItemsSold = transactions.reduce(
    (sum, t) => sum + t.items.reduce((iSum, item) => iSum + item.quantity, 0),
    0
  )

  return (
    <div className="space-y-6">
      {/* Top summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-xl bg-white border border-stone-200/80 shadow-xs">
          <p className="text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1">Total Pendapatan</p>
          <p className="font-serif text-2xl font-bold text-stone-900">{formatRupiah(totalRevenue)}</p>
          <span className="text-[11px] text-stone-400 mt-1 inline-block">Dari {transactions.length} transaksi selesai</span>
        </div>

        <div className="p-5 rounded-xl bg-white border border-stone-200/80 shadow-xs">
          <p className="text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1">Total Transaksi</p>
          <p className="font-serif text-2xl font-bold text-stone-900">{transactions.length}</p>
          <span className="text-[11px] text-emerald-600 font-medium mt-1 inline-block">100% Berhasil</span>
        </div>

        <div className="p-5 rounded-xl bg-white border border-stone-200/80 shadow-xs">
          <p className="text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1">Item Terjual</p>
          <p className="font-serif text-2xl font-bold text-stone-900">{totalItemsSold} porsi</p>
          <span className="text-[11px] text-stone-400 mt-1 inline-block">Termasuk produk & minuman</span>
        </div>
      </div>

      {/* Transaction List Table */}
      <div className="bg-white rounded-xl border border-stone-200/80 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between">
          <div>
            <h3 className="font-serif text-lg font-semibold text-stone-900">Riwayat Penjualan Kasir</h3>
            <p className="text-xs text-stone-500">Semua riwayat transaksi struk pembayaran</p>
          </div>
          <span className="text-xs font-mono text-stone-500 bg-stone-100 px-2.5 py-1 rounded-md">
            {transactions.length} Rekaman
          </span>
        </div>

        {transactions.length === 0 ? (
          <div className="p-12 text-center text-stone-400 space-y-2">
            <Receipt className="w-10 h-10 mx-auto text-stone-300" />
            <p className="text-sm font-medium text-stone-600">Belum ada riwayat transaksi</p>
            <p className="text-xs text-stone-400">Transaksi yang telah dibayar akan muncul di sini</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-stone-50/70 border-b border-stone-100 text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
                <tr>
                  <th className="px-6 py-3.5">Invoice</th>
                  <th className="px-6 py-3.5">Waktu</th>
                  <th className="px-6 py-3.5">Pelanggan</th>
                  <th className="px-6 py-3.5">Item</th>
                  <th className="px-6 py-3.5">Metode</th>
                  <th className="px-6 py-3.5 text-right">Total</th>
                  <th className="px-6 py-3.5 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {transactions.map(tx => (
                  <tr key={tx.id} className="hover:bg-stone-50/50 transition-colors">
                    <td className="px-6 py-4 font-mono font-medium text-xs text-stone-800">
                      {tx.invoiceNumber}
                    </td>
                    <td className="px-6 py-4 text-xs text-stone-500">
                      {tx.date}
                    </td>
                    <td className="px-6 py-4 text-stone-800 font-medium">
                      {tx.customerName || '-'}
                    </td>
                    <td className="px-6 py-4 text-xs text-stone-600">
                      <span className="font-medium text-stone-800">
                        {tx.items.reduce((s, i) => s + i.quantity, 0)} item
                      </span>
                      <span className="text-[11px] text-stone-400 block truncate max-w-[180px]">
                        {tx.items.map(i => `${i.product.name} (${i.quantity})`).join(', ')}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold uppercase bg-stone-100 text-stone-700">
                        <CreditCard className="w-3 h-3 text-stone-500" />
                        {tx.paymentMethod}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right font-serif font-bold text-stone-900">
                      {formatRupiah(tx.total)}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <button
                        onClick={() => onViewReceipt(tx)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-stone-700 bg-stone-100 hover:bg-stone-200/80 rounded-lg transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        Lihat Struk
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
